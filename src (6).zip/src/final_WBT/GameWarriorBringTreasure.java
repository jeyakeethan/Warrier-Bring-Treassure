package final_WBT;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

/**
 * This is the main class having all objects(Composition). Game is started in
 * this class
 * 
 */
public class GameWarriorBringTreasure {
	public static ArrayList<Fish> fishList = new ArrayList<>();
	public static ArrayList<Treasure> treasureList = new ArrayList<>();
	public static ArrayList<Warrior> warriorList = new ArrayList<>();

	public static ArrayList<Inhabitant> inhabitantList = new ArrayList<>();

	public static Thread[] warriorThreads;
	public static Thread[] fishThreads;


	public static void main(String[] args) {
		GUI gui = new GUI();
		Grid.setGui(gui);
		Grid.generateNodes();
		Grid.fillGridWithNode();

		/*
		 * Four Warrior objects are created and set them into one side of the grid.
		 */
		Warrior normalWarrior1 = new NormalWarrior("WarriorA");
		Warrior normalWarrior2 = new NormalWarrior("WarriorB");
		Warrior superWarrior1 = new SuperWarrior("SuperWarriorA");
		Warrior superWarrior2 = new SuperWarrior("SuperWarriorB");
		Grid.setInhabitantPosition(0, 0, normalWarrior1);
		Grid.setInhabitantPosition(3, 0, normalWarrior2);
		Grid.setInhabitantPosition(6, 0, superWarrior1);
		Grid.setInhabitantPosition(10, 0, superWarrior2);
		inhabitantList.add(normalWarrior1);
		inhabitantList.add(normalWarrior2);
		inhabitantList.add(superWarrior1);
		inhabitantList.add(superWarrior2);
		warriorList.add(normalWarrior1);
		warriorList.add(normalWarrior2);
		warriorList.add(superWarrior1);
		warriorList.add(superWarrior2);

		/*
		 * Six Fish objects are created and randomly set to the grid locations.
		 */
		Fish rubberFish1 = new RubberFish("RubberFishA");
		Fish rubberFish2 = new RubberFish("RubberFishB");
		Fish killerFish1 = new KillerFish("KillerFishA");
		Fish killerFish2 = new KillerFish("KillerFishB");
		Fish innocentFish1 = new InnocentFish("InnocentFishA");
		Fish innocentFish2 = new InnocentFish("InnocentFishB");
		Grid.setInhabitantPosition(rubberFish1);
		Grid.setInhabitantPosition(rubberFish2);
		Grid.setInhabitantPosition(killerFish1);
		Grid.setInhabitantPosition(killerFish2);
		Grid.setInhabitantPosition(innocentFish1);
		Grid.setInhabitantPosition(innocentFish2);
		inhabitantList.add(rubberFish1);
		inhabitantList.add(rubberFish2);
		inhabitantList.add(killerFish1);
		inhabitantList.add(killerFish2);
		inhabitantList.add(innocentFish1);
		inhabitantList.add(innocentFish2);

		/*
		 * Five lotus objects are created and randomly set to the grid locations.
		 */
		Lotus lotus1 = new Lotus("lotusA");
		Lotus lotus2 = new Lotus("lotusB");
		Lotus lotus3 = new Lotus("lotusC");
		Lotus lotus4 = new Lotus("lotusD");
		Lotus lotus5 = new Lotus("lotusE");
		Grid.setInhabitantPosition(lotus1);
		Grid.setInhabitantPosition(lotus2);
		Grid.setInhabitantPosition(lotus3);
		Grid.setInhabitantPosition(lotus4);
		Grid.setInhabitantPosition(lotus5);

		/*
		 * Treasure is fixed and the only at 5,5 in this game and warriors know it.
		 */
		Treasure treasure1 = new Treasure("TheTreasure", normalWarrior1, normalWarrior2, superWarrior1, superWarrior2);
		Grid.setInhabitantPosition(5, 5, treasure1);

		for (Inhabitant i : inhabitantList) {
			System.out.println(i.getClass().getName() + " : " + i.getName()+" @ "+i.getNode().toString());
		}
		System.out.println();

		warriorThreads = new Thread[warriorList.size()];
		int count = 0;
		for (Warrior warrior : warriorList) {
			warriorThreads[count] = new Thread(warrior);
			warriorThreads[count].start();
			count++;
		}
		fishThreads = new Thread[fishList.size()];
		count = 0;
		for (Fish fish : fishList) {
			fishThreads[count] = new Thread(fish);
			fishThreads[count].start();
			count++;
		}
	}

	/**

	 */
	public static void stopGame() {
		for(Thread fish:fishThreads) {
			fish.interrupt();
		}
	}

}
