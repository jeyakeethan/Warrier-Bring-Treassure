package final_WBT;

import javax.swing.JFrame;
import javax.swing.JTable;
import java.awt.BorderLayout;
import javax.swing.table.DefaultTableModel;
import java.awt.GridLayout;
import javax.swing.JSplitPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.border.BevelBorder;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import com.jgoodies.forms.layout.FormSpecs;
import java.awt.Panel;
import javax.swing.JRadioButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;

public class GUI extends JFrame {
	JLabel[][] labelList = new JLabel[10][10];
	ImageIcon sWarrior, nWarrior, iFish, rFish, kFish, treasure, lotus;

	public GUI() {
		getContentPane().setLayout(new GridLayout(10, 10, 1, 1));

		JPanel panel0 = new JPanel();
		getContentPane().add(panel0);
		JLabel label0 = new JLabel();
		panel0.add(label0);
		labelList[0][0] = label0;

		JPanel panel1 = new JPanel();
		getContentPane().add(panel1);
		JLabel label1 = new JLabel();
		panel1.add(label1);
		labelList[0][1] = label1;

		JPanel panel2 = new JPanel();
		getContentPane().add(panel2);
		JLabel label2 = new JLabel();
		panel2.add(label2);
		labelList[0][2] = label2;

		JPanel panel3 = new JPanel();
		getContentPane().add(panel3);
		JLabel label3 = new JLabel();
		panel3.add(label3);
		labelList[0][3] = label3;

		JPanel panel4 = new JPanel();
		getContentPane().add(panel4);
		JLabel label4 = new JLabel();
		panel4.add(label4);
		labelList[0][4] = label4;

		JPanel panel5 = new JPanel();
		getContentPane().add(panel5);
		JLabel label5 = new JLabel();
		panel5.add(label5);
		labelList[0][5] = label5;

		JPanel panel6 = new JPanel();
		getContentPane().add(panel6);
		JLabel label6 = new JLabel();
		panel6.add(label6);
		labelList[0][6] = label6;

		JPanel panel7 = new JPanel();
		getContentPane().add(panel7);
		JLabel label7 = new JLabel();
		panel7.add(label7);
		labelList[0][7] = label7;

		JPanel panel8 = new JPanel();
		getContentPane().add(panel8);
		JLabel label8 = new JLabel();
		panel8.add(label8);
		labelList[0][8] = label8;

		JPanel panel9 = new JPanel();
		getContentPane().add(panel9);
		JLabel label9 = new JLabel();
		panel9.add(label9);
		labelList[0][9] = label9;

		JPanel panel10 = new JPanel();
		getContentPane().add(panel10);
		JLabel label10 = new JLabel();
		panel10.add(label10);
		labelList[1][0] = label10;

		JPanel panel11 = new JPanel();
		getContentPane().add(panel11);
		JLabel label11 = new JLabel();
		panel11.add(label11);
		labelList[1][1] = label11;

		JPanel panel12 = new JPanel();
		getContentPane().add(panel12);
		JLabel label12 = new JLabel();
		panel12.add(label12);
		labelList[1][2] = label12;

		JPanel panel13 = new JPanel();
		getContentPane().add(panel13);
		JLabel label13 = new JLabel();
		panel13.add(label13);
		labelList[1][3] = label13;

		JPanel panel14 = new JPanel();
		getContentPane().add(panel14);
		JLabel label14 = new JLabel();
		panel14.add(label14);
		labelList[1][4] = label14;

		JPanel panel15 = new JPanel();
		getContentPane().add(panel15);
		JLabel label15 = new JLabel();
		panel15.add(label15);
		labelList[1][5] = label15;

		JPanel panel16 = new JPanel();
		getContentPane().add(panel16);
		JLabel label16 = new JLabel();
		panel16.add(label16);
		labelList[1][6] = label16;

		JPanel panel17 = new JPanel();
		getContentPane().add(panel17);
		JLabel label17 = new JLabel();
		panel17.add(label17);
		labelList[1][7] = label17;

		JPanel panel18 = new JPanel();
		getContentPane().add(panel18);
		JLabel label18 = new JLabel();
		panel18.add(label18);
		labelList[1][8] = label18;

		JPanel panel19 = new JPanel();
		getContentPane().add(panel19);
		JLabel label19 = new JLabel();
		panel19.add(label19);
		labelList[1][9] = label19;

		JPanel panel20 = new JPanel();
		getContentPane().add(panel20);
		JLabel label20 = new JLabel();
		panel20.add(label20);
		labelList[2][0] = label20;

		JPanel panel21 = new JPanel();
		getContentPane().add(panel21);
		JLabel label21 = new JLabel();
		panel21.add(label21);
		labelList[2][1] = label21;

		JPanel panel22 = new JPanel();
		getContentPane().add(panel22);
		JLabel label22 = new JLabel();
		panel22.add(label22);
		labelList[2][2] = label22;

		JPanel panel23 = new JPanel();
		getContentPane().add(panel23);
		JLabel label23 = new JLabel();
		panel23.add(label23);
		labelList[2][3] = label23;

		JPanel panel24 = new JPanel();
		getContentPane().add(panel24);
		JLabel label24 = new JLabel();
		panel24.add(label24);
		labelList[2][4] = label24;

		JPanel panel25 = new JPanel();
		getContentPane().add(panel25);
		JLabel label25 = new JLabel();
		panel25.add(label25);
		labelList[2][5] = label25;

		JPanel panel26 = new JPanel();
		getContentPane().add(panel26);
		JLabel label26 = new JLabel();
		panel26.add(label26);
		labelList[2][6] = label26;

		JPanel panel27 = new JPanel();
		getContentPane().add(panel27);
		JLabel label27 = new JLabel();
		panel27.add(label27);
		labelList[2][7] = label27;

		JPanel panel28 = new JPanel();
		getContentPane().add(panel28);
		JLabel label28 = new JLabel();
		panel28.add(label28);
		labelList[2][8] = label28;

		JPanel panel29 = new JPanel();
		getContentPane().add(panel29);
		JLabel label29 = new JLabel();
		panel29.add(label29);
		labelList[2][9] = label29;

		JPanel panel30 = new JPanel();
		getContentPane().add(panel30);
		JLabel label30 = new JLabel();
		panel30.add(label30);
		labelList[3][0] = label30;

		JPanel panel31 = new JPanel();
		getContentPane().add(panel31);
		JLabel label31 = new JLabel();
		panel31.add(label31);
		labelList[3][1] = label31;

		JPanel panel32 = new JPanel();
		getContentPane().add(panel32);
		JLabel label32 = new JLabel();
		panel32.add(label32);
		labelList[3][2] = label32;

		JPanel panel33 = new JPanel();
		getContentPane().add(panel33);
		JLabel label33 = new JLabel();
		panel33.add(label33);
		labelList[3][3] = label33;

		JPanel panel34 = new JPanel();
		getContentPane().add(panel34);
		JLabel label34 = new JLabel();
		panel34.add(label34);
		labelList[3][4] = label34;

		JPanel panel35 = new JPanel();
		getContentPane().add(panel35);
		JLabel label35 = new JLabel();
		panel35.add(label35);
		labelList[3][5] = label35;

		JPanel panel36 = new JPanel();
		getContentPane().add(panel36);
		JLabel label36 = new JLabel();
		panel36.add(label36);
		labelList[3][6] = label36;

		JPanel panel37 = new JPanel();
		getContentPane().add(panel37);
		JLabel label37 = new JLabel();
		panel37.add(label37);
		labelList[3][7] = label37;

		JPanel panel38 = new JPanel();
		getContentPane().add(panel38);
		JLabel label38 = new JLabel();
		panel38.add(label38);
		labelList[3][8] = label38;

		JPanel panel39 = new JPanel();
		getContentPane().add(panel39);
		JLabel label39 = new JLabel();
		panel39.add(label39);
		labelList[3][9] = label39;

		JPanel panel40 = new JPanel();
		getContentPane().add(panel40);
		JLabel label40 = new JLabel();
		panel40.add(label40);
		labelList[4][0] = label40;

		JPanel panel41 = new JPanel();
		getContentPane().add(panel41);
		JLabel label41 = new JLabel();
		panel41.add(label41);
		labelList[4][1] = label41;

		JPanel panel42 = new JPanel();
		getContentPane().add(panel42);
		JLabel label42 = new JLabel();
		panel42.add(label42);
		labelList[4][2] = label42;

		JPanel panel43 = new JPanel();
		getContentPane().add(panel43);
		JLabel label43 = new JLabel();
		panel43.add(label43);
		labelList[4][3] = label43;

		JPanel panel44 = new JPanel();
		getContentPane().add(panel44);
		JLabel label44 = new JLabel();
		panel44.add(label44);
		labelList[4][4] = label44;

		JPanel panel45 = new JPanel();
		getContentPane().add(panel45);
		JLabel label45 = new JLabel();
		panel45.add(label45);
		labelList[4][5] = label45;

		JPanel panel46 = new JPanel();
		getContentPane().add(panel46);
		JLabel label46 = new JLabel();
		panel46.add(label46);
		labelList[4][6] = label46;

		JPanel panel47 = new JPanel();
		getContentPane().add(panel47);
		JLabel label47 = new JLabel();
		panel47.add(label47);
		labelList[4][7] = label47;

		JPanel panel48 = new JPanel();
		getContentPane().add(panel48);
		JLabel label48 = new JLabel();
		panel48.add(label48);
		labelList[4][8] = label48;

		JPanel panel49 = new JPanel();
		getContentPane().add(panel49);
		JLabel label49 = new JLabel();
		panel49.add(label49);
		labelList[4][9] = label49;

		JPanel panel50 = new JPanel();
		getContentPane().add(panel50);
		JLabel label50 = new JLabel();
		panel50.add(label50);
		labelList[5][0] = label50;

		JPanel panel51 = new JPanel();
		getContentPane().add(panel51);
		JLabel label51 = new JLabel();
		panel51.add(label51);
		labelList[5][1] = label51;

		JPanel panel52 = new JPanel();
		getContentPane().add(panel52);
		JLabel label52 = new JLabel();
		panel52.add(label52);
		labelList[5][2] = label52;

		JPanel panel53 = new JPanel();
		getContentPane().add(panel53);
		JLabel label53 = new JLabel();
		panel53.add(label53);
		labelList[5][3] = label53;

		JPanel panel54 = new JPanel();
		getContentPane().add(panel54);
		JLabel label54 = new JLabel();
		panel54.add(label54);
		labelList[5][4] = label54;

		JPanel panel55 = new JPanel();
		getContentPane().add(panel55);
		JLabel label55 = new JLabel();
		panel55.add(label55);
		labelList[5][5] = label55;

		JPanel panel56 = new JPanel();
		getContentPane().add(panel56);
		JLabel label56 = new JLabel();
		panel56.add(label56);
		labelList[5][6] = label56;

		JPanel panel57 = new JPanel();
		getContentPane().add(panel57);
		JLabel label57 = new JLabel();
		panel57.add(label57);
		labelList[5][7] = label57;

		JPanel panel58 = new JPanel();
		getContentPane().add(panel58);
		JLabel label58 = new JLabel();
		panel58.add(label58);
		labelList[5][8] = label58;

		JPanel panel59 = new JPanel();
		getContentPane().add(panel59);
		JLabel label59 = new JLabel();
		panel59.add(label59);
		labelList[5][9] = label59;

		JPanel panel60 = new JPanel();
		getContentPane().add(panel60);
		JLabel label60 = new JLabel();
		panel60.add(label60);
		labelList[6][0] = label60;

		JPanel panel61 = new JPanel();
		getContentPane().add(panel61);
		JLabel label61 = new JLabel();
		panel61.add(label61);
		labelList[6][1] = label61;

		JPanel panel62 = new JPanel();
		getContentPane().add(panel62);
		JLabel label62 = new JLabel();
		panel62.add(label62);
		labelList[6][2] = label62;

		JPanel panel63 = new JPanel();
		getContentPane().add(panel63);
		JLabel label63 = new JLabel();
		panel63.add(label63);
		labelList[6][3] = label63;

		JPanel panel64 = new JPanel();
		getContentPane().add(panel64);
		JLabel label64 = new JLabel();
		panel64.add(label64);
		labelList[6][4] = label64;

		JPanel panel65 = new JPanel();
		getContentPane().add(panel65);
		JLabel label65 = new JLabel();
		panel65.add(label65);
		labelList[6][5] = label65;

		JPanel panel66 = new JPanel();
		getContentPane().add(panel66);
		JLabel label66 = new JLabel();
		panel66.add(label66);
		labelList[6][6] = label66;

		JPanel panel67 = new JPanel();
		getContentPane().add(panel67);
		JLabel label67 = new JLabel();
		panel67.add(label67);
		labelList[6][7] = label67;

		JPanel panel68 = new JPanel();
		getContentPane().add(panel68);
		JLabel label68 = new JLabel();
		panel68.add(label68);
		labelList[6][8] = label68;

		JPanel panel69 = new JPanel();
		getContentPane().add(panel69);
		JLabel label69 = new JLabel();
		panel69.add(label69);
		labelList[6][9] = label69;

		JPanel panel70 = new JPanel();
		getContentPane().add(panel70);
		JLabel label70 = new JLabel();
		panel70.add(label70);
		labelList[7][0] = label70;

		JPanel panel71 = new JPanel();
		getContentPane().add(panel71);
		JLabel label71 = new JLabel();
		panel71.add(label71);
		labelList[7][1] = label71;

		JPanel panel72 = new JPanel();
		getContentPane().add(panel72);
		JLabel label72 = new JLabel();
		panel72.add(label72);
		labelList[7][2] = label72;

		JPanel panel73 = new JPanel();
		getContentPane().add(panel73);
		JLabel label73 = new JLabel();
		panel73.add(label73);
		labelList[7][3] = label73;

		JPanel panel74 = new JPanel();
		getContentPane().add(panel74);
		JLabel label74 = new JLabel();
		panel74.add(label74);
		labelList[7][4] = label74;

		JPanel panel75 = new JPanel();
		getContentPane().add(panel75);
		JLabel label75 = new JLabel();
		panel75.add(label75);
		labelList[7][5] = label75;

		JPanel panel76 = new JPanel();
		getContentPane().add(panel76);
		JLabel label76 = new JLabel();
		panel76.add(label76);
		labelList[7][6] = label76;

		JPanel panel77 = new JPanel();
		getContentPane().add(panel77);
		JLabel label77 = new JLabel();
		panel77.add(label77);
		labelList[7][7] = label77;

		JPanel panel78 = new JPanel();
		getContentPane().add(panel78);
		JLabel label78 = new JLabel();
		panel78.add(label78);
		labelList[7][8] = label78;

		JPanel panel79 = new JPanel();
		getContentPane().add(panel79);
		JLabel label79 = new JLabel();
		panel79.add(label79);
		labelList[7][9] = label79;

		JPanel panel80 = new JPanel();
		getContentPane().add(panel80);
		JLabel label80 = new JLabel();
		panel80.add(label80);
		labelList[8][0] = label80;

		JPanel panel81 = new JPanel();
		getContentPane().add(panel81);
		JLabel label81 = new JLabel();
		panel81.add(label81);
		labelList[8][1] = label81;

		JPanel panel82 = new JPanel();
		getContentPane().add(panel82);
		JLabel label82 = new JLabel();
		panel82.add(label82);
		labelList[8][2] = label82;

		JPanel panel83 = new JPanel();
		getContentPane().add(panel83);
		JLabel label83 = new JLabel();
		panel83.add(label83);
		labelList[8][3] = label83;

		JPanel panel84 = new JPanel();
		getContentPane().add(panel84);
		JLabel label84 = new JLabel();
		panel84.add(label84);
		labelList[8][4] = label84;

		JPanel panel85 = new JPanel();
		getContentPane().add(panel85);
		JLabel label85 = new JLabel();
		panel85.add(label85);
		labelList[8][5] = label85;

		JPanel panel86 = new JPanel();
		getContentPane().add(panel86);
		JLabel label86 = new JLabel();
		panel86.add(label86);
		labelList[8][6] = label86;

		JPanel panel87 = new JPanel();
		getContentPane().add(panel87);
		JLabel label87 = new JLabel();
		panel87.add(label87);
		labelList[8][7] = label87;

		JPanel panel88 = new JPanel();
		getContentPane().add(panel88);
		JLabel label88 = new JLabel();
		panel88.add(label88);
		labelList[8][8] = label88;

		JPanel panel89 = new JPanel();
		getContentPane().add(panel89);
		JLabel label89 = new JLabel();
		panel89.add(label89);
		labelList[8][9] = label89;

		JPanel panel90 = new JPanel();
		getContentPane().add(panel90);
		JLabel label90 = new JLabel();
		panel90.add(label90);
		labelList[9][0] = label90;

		JPanel panel91 = new JPanel();
		getContentPane().add(panel91);
		JLabel label91 = new JLabel();
		panel91.add(label91);
		labelList[9][1] = label91;

		JPanel panel92 = new JPanel();
		getContentPane().add(panel92);
		JLabel label92 = new JLabel();
		panel92.add(label92);
		labelList[9][2] = label92;

		JPanel panel93 = new JPanel();
		getContentPane().add(panel93);
		JLabel label93 = new JLabel();
		panel93.add(label93);
		labelList[9][3] = label93;

		JPanel panel94 = new JPanel();
		getContentPane().add(panel94);
		JLabel label94 = new JLabel();
		panel94.add(label94);
		labelList[9][4] = label94;

		JPanel panel95 = new JPanel();
		getContentPane().add(panel95);
		JLabel label95 = new JLabel();
		panel95.add(label95);
		labelList[9][5] = label95;

		JPanel panel96 = new JPanel();
		getContentPane().add(panel96);
		JLabel label96 = new JLabel();
		panel96.add(label96);
		labelList[9][6] = label96;

		JPanel panel97 = new JPanel();
		getContentPane().add(panel97);
		JLabel label97 = new JLabel();
		panel97.add(label97);
		labelList[9][7] = label97;

		JPanel panel98 = new JPanel();
		getContentPane().add(panel98);
		JLabel label98 = new JLabel();
		panel98.add(label98);
		labelList[9][8] = label98;

		JPanel panel99 = new JPanel();
		getContentPane().add(panel99);
		JLabel label99 = new JLabel();
		panel99.add(label99);
		labelList[9][9] = label99;
		
		label0.setIcon(new ImageIcon("D:\\j.png"));
	}
}
