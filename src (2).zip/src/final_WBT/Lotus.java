package final_WBT;
public class Lotus implements Inhabitant{

	private String name;
	private int petals;
	private boolean isContainPetals;
	private Node node;

	public Lotus(String name) {
		this.name = name;
		petals = 100;
		isContainPetals = true;
		
		GameWarriorBringTreasure.lotusList.add(this);
		
		this.setNode(Grid.setInhabitantPosition(-1, -1, this));
	}

	public void decrementPetal() {
		petals--;
		if (petals == 0) {
			isContainPetals = false;
		}
	}

	public boolean getPetalAvailability() {
		return isContainPetals;
	}

	public Node getNode() {
		return node;
	}
	
	public String getName() {
		return name;
	}

	public void setNode(Node node) {
		this.node = node;
	}

}
