package final_WBT;

public class Node extends Grid {
	private Fish fish;
	private Warrior warrior;
	private Lotus lotus;
	private Treasure treasure;
	private int x, y;

	public Node(int x, int y) {
		this.x = x;
		this.y = y;

		setFish(null);
		setWarrior(null);
		setLotus(null);
		setTreasure(null);
	}

	public synchronized boolean setInhabitant(Inhabitant inhabitant) {
		if (inhabitant instanceof Warrior) {
			if (getWarrior() == null) {
				setWarrior((Warrior) inhabitant);
				notifyAll();
				if (lotus != null)
					((Warrior) inhabitant).eatLotus(lotus);
				if (treasure != null) {
					((Warrior) inhabitant).grabTreasure(treasure);
					treasure.notifyTreasureIsGrabbed(((Warrior) inhabitant));
				}
			} else {
				return false;
			}
		} else if (inhabitant instanceof Fish) {
			this.setFish((Fish) inhabitant);
			this.getFish().setNode(this);
		} else if (inhabitant instanceof Lotus) {
			this.setLotus((Lotus) inhabitant);
		} else if (inhabitant instanceof Treasure) {
			this.setTreasure((Treasure) inhabitant);
		}
		return true;
	}

	public synchronized void clearWarrior() {
		setWarrior(null);
	}

	public synchronized void lookArround() {
		while (getWarrior() == null) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		getFish().attackWarrior(this);
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	private void setCordinate(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public Fish getFish() {
		return fish;
	}

	public void setFish(Fish fish) {
		this.fish = fish;
	}

	public Warrior getWarrior() {
		return warrior;
	}

	public void setWarrior(Warrior warrior) {
		this.warrior = warrior;
	}

	public Lotus getLotus() {
		return lotus;
	}

	public void setLotus(Lotus lotus) {
		this.lotus = lotus;
	}

	public Treasure getTreasure() {
		return treasure;
	}

	public void setTreasure(Treasure treasure) {
		this.treasure = treasure;
	}

}