package final_WBT;
public class Fin {
	// this class is just for using the OOP has a relationship concept
}
