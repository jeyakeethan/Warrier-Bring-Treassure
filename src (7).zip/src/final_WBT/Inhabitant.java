package final_WBT;

interface Inhabitant {

	String getName();

	Node getNode();

	void setNode(Node node);
}
