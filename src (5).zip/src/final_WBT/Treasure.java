package final_WBT;

public class Treasure implements Inhabitant {
	private String name;
	private Node node;
	private Warrior[] warriorList;

	public Treasure(String name, Warrior... warrior) {
		this.name = name;
		this.warriorList = warrior;

		GameWarriorBringTreasure.treasureList.add(this);
	}



	/**
	 * to notify all warrior that the Treasure has been grabbed
	 * @param grabbedWarrior
	 */
	public synchronized void notifyTreasureIsGrabbed(Warrior grabbedWarrior) {
		GameWarriorBringTreasure.stopGame();
		for (Warrior warrior : warriorList) {
			warrior.setTreasureGrabbed(true);
		}
		GameWarriorBringTreasure.stopGame();
		System.out.println(String.format(grabbedWarrior.getName() + " has grabbed the treasure and become winner\n"));
	}

	/*--- Getter and Setter section ---*/
	public String getName() {
		return name;
	}

	public Node getNode() {
		return node;
	}

	public void setNode(Node node) {
		this.node = node;
	}
}
