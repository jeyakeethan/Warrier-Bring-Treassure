package final_WBT;

public class Visual {
	static int chk = -1;

	/**
	 * this static method is to show us, what is happening inside as a sketch map
	 * special symbols used for each entity
	 */
	public static synchronized void PrintWarriorMap() {
		chk++;
		if (chk % 4 == 0) {
			System.out.println();
			for (int j = 9; j >= 0; j--) {
				for (int k = 0; k < 10; k++) {
					Node node = Grid.getGrid()[k][j];
					if (GameWarriorBringTreasure.treasureGrabbed) {
						System.out.print("[*]");
					} else if (node.getWarrior() instanceof SuperWarrior) {
						System.out.print("[$]");
					} else if (node.getWarrior() instanceof NormalWarrior) {
						System.out.print("[&]");
					} else if (node.getTreasure() instanceof Treasure) {
						System.out.print("[@]");
					} else if (node.getFish() instanceof RubberFish) {
						System.out.print("[#]");
					} else if (node.getFish() instanceof KillerFish) {
						System.out.print("[+]");
					} else if (node.getFish() instanceof InnocentFish) {
						System.out.print("[:]");
					} else if (node.getLotus() instanceof Lotus) {
						System.out.print("[*]");
					} else {
						System.out.print("[ ]");
					}
				}
				System.out.println();
			}
		}
		try {
			Thread.sleep(400);
		} catch (InterruptedException e) {}
	}

	public static synchronized void pintOut(String str) {
		System.out.print(str);
	}

}
