package final_WBT;

public abstract class Fish implements Inhabitant, Runnable {

	private static volatile boolean gameStopped = false;

	private String name;
	private Node node;

	/**
	 * a warrior object should be passed as parameter to this method
	 */
	public abstract void attackWarrior(Node node);

	public void run() {
		while (!gameStopped)
			this.getNode().lookArround();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Node getNode() {
		return node;
	}

	public void setNode(Node node) {
		this.node = node;
	}

	public static void setGameStopped(boolean gs) {
		gameStopped = gs;
	}

}
