package final_WBT;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Grid {
	private static Node grid[][];
	private static ArrayList nodeList;
	protected static GUI gui;

	private static Random randomInt = new Random();
	/**
	 * to generate/ reset random node array which is not reserved before
	 * 
	 * @return
	 */
	public static ArrayList<int[]> generateNodes() {
nodeList = new ArrayList();
		for (int x = 2; x < 10; x++) {
			for (int y = 1; y < 10; y++) {
				int[] cordinate = { x, y };
				nodeList.add(cordinate);
			}
		}
		int[] center = { 4, 4 };
		nodeList.remove(center);
		return (ArrayList<int[]>) nodeList;
	}

	public static void fillGridWithNode() {
grid = new Node[10][10];
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				grid[i][j] = new Node(i,j);
			}
		}

	}

	/**
	 * set new position to warrior swimming it also call the message methods which
	 * are inside this class
	 * 
	 * @param a
	 *            -1 => random
	 * @param b
	 *            -1 => random
	 */
	public static Node setInhabitantPosition(int a, int b, Inhabitant inhabitant) {
		int[] cordinate;
		if (a == -1 && b == -1) {
			cordinate = generateRandomCordinate();
			a = cordinate[0];
			b = cordinate[1];
		}
			grid[a][b].setInhabitant(inhabitant);
		return grid[a][b];
	}

	/**
	 * to get random coordinate that available the coordinate is restricted by
	 * object type going to reserve it
	 * 
	 * @param type
	 * @return
	 */
	public static int[] generateRandomCordinate() {
		int[] node = (int[]) nodeList.remove(randomInt.nextInt(nodeList.size()));
		return node;
	}
	
	public static Node[][] getGrid(){
		return grid;
	}
	
	public static void setGui(GUI guiIn) {
		gui = guiIn;
	}
}
