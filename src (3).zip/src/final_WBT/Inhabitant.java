package final_WBT;

interface Inhabitant {

	public String getName();
	public Node getNode();
}
