package final_WBT;

public class InnocentFish extends Fish {
	public InnocentFish(String name) {
		this.setName(name);
		this.setNode(Grid.setInhabitantPosition(-1, -1, this));
		GameWarriorBringTreasure.fishList.add(this);
	}

	/**
	 * to be called by grid class if coordinates are same. to attack the warrior
	 */
	public void attackWarrior() {
			Node node = this.getNode();
			node.lookupWarrior();
			System.out.println("I don't make you anything. Calm Down!");
	}
}
