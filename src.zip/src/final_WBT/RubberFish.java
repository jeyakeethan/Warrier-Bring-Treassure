package final_WBT;

public class RubberFish extends Fish {
	public RubberFish(String name) {
		this.setName(name);
		this.setNode(Grid.setInhabitantPosition(-1, -1, this));

		GameWarriorBringTreasure.fishList.add(this);
	}

	/**
	 * to be called by grid class if coordinates are same. to attack the warrior
	 */
	public void attackWarrior() {
		Node node = this.getNode();
		node.lookupWarrior();
		if (!node.getWarrior().isImmortal()) {
			node.getWarrior().setMobility(false);
			node.getWarrior().fin = null;
			System.out.printf("%s has eaten fins of the %s => %s can't move anymore\n", this.getName(),
					node.getWarrior().getName(), node.getWarrior().getName());
		}
	}
}
