package final_WBT;

public class NormalWarrior extends Warrior {

	public NormalWarrior(String name, int startingX, Node grid[][] ) {
		this.grid = grid;
		noOfWarriors++;
		this.name = name;
		this.Immortal = false;
		this.mobility = true;

		setNode(Grid.setInhabitantPosition(startingX - 1, 0, this));
	}

	public void eatLotus(Lotus lotus) {
		System.out.printf("%s: Thanks for the lotus\n", name);
	}

	public void sleep() {
		System.out.println(this.getName() + "is sleeping");
	}

	public synchronized void swim() {
		while (mobility) {
			int x = getNode().getX();
			int y = getNode().getY();
			int randDirection = random.nextInt(2);
			switch (randDirection) {
			case 0:
				// move in y direction if random number is zero
				if (y < 4 && grid[x][y + 1].setInhabitant(this)) {
					grid[x][y].clearWarrior();
					setNode(grid[x][y + 1]);
					break;
				} else if (y > 4 && grid[x][y - 1].setInhabitant(this)) {
					grid[x][y].clearWarrior();
					setNode(grid[x][y - 1]);
					break;
				} else if (y < 9 && grid[x][y + 1].setInhabitant(this)) {
					grid[x][y].clearWarrior();
					setNode(grid[x][y + 1]);
					break;
				} else {
					randDirection = 1;
				}
			case 1:
				// move in x direction if random number is one
				if (x < 4 && grid[x + 1][y].setInhabitant(this)) {
					grid[x][y].clearWarrior();
					setNode(grid[x + 1][y]);
					break;
				} else if (x > 4 && grid[x - 1][y].setInhabitant(this)) {
					grid[x][y].clearWarrior();
					setNode(grid[x - 1][y]);
					break;
				} else if (x < 9 && grid[x + 1][y].setInhabitant(this)) {
					grid[x][y].clearWarrior();
					setNode(grid[x + 1][y]);
					break;
				} else if (x > 1 && grid[x - 1][y].setInhabitant(this)) {
					grid[x][y].clearWarrior();
					setNode(grid[x - 1][y]);
					break;
				} else {
					//continue;
				}
			}
			Visual.PrintWarriorMap();
		}
	}

}
