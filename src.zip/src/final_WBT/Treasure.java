package final_WBT;
public class Treasure implements Inhabitant{
    private String name;
    private Node node;
    private Warrior[] warrior;
    
    public Treasure(String name, int x, int y, Warrior...warrior) {
        this.name = name;
        this.node = Grid.setInhabitantPosition(x, y, this);
        this.warrior = warrior;
        
        GameWarriorBringTreasure.treasureList.add(this);
    }

    public Node getLocation() {
    	return node;
    }
    
    /**
     * to notify all warrior that warrior is grabbed as on project description
     * @param grabbedWarrior
     */
    public void notifyTreasureIsGrabbed(Warrior grabbedWarrior) {
    	System.out.println(grabbedWarrior.getName()+" has grabbed the treasure and become winner");
    	GameWarriorBringTreasure.stopGame();
    }
    
    public String getName() {
    	return name;
    }

}
