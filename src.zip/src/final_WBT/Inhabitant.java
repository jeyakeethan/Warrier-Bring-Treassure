package final_WBT;

interface Inhabitant {

	public String getName();
}
