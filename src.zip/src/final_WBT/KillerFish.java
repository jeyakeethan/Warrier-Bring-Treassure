package final_WBT;

public class KillerFish extends Fish {

	public KillerFish(String name) {
		this.setName(name);
		this.setNode(Grid.setInhabitantPosition(-1, -1, this));

		GameWarriorBringTreasure.fishList.add(this);
	}

	/**
	 * to be called by grid class if coordinates are same. to attack the warrior to
	 * kill warrior if the warrior is not immortal
	 */
	public void attackWarrior() {
		Node node = this.getNode();
		node.lookupWarrior();
		if (!node.getWarrior().isImmortal()) {
			node.clearWarrior(); // remove warrior object
			node.getWarrior().setMobility(false);
			System.out.println(this.getName() + " has killed " + node.getWarrior().getName());
		} else {
			System.out.printf("%s has escaped from %s as %s is an immortal\n", node.getWarrior().getName(),
					this.getName(), node.getWarrior().getName());
		}
	}
}
