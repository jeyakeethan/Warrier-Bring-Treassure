package final_WBT;

import java.util.Random;
import java.util.concurrent.TimeUnit;

public abstract class Warrior implements Inhabitant, Runnable {
	public static Object object1 = new Object();
	protected static int noOfWarriors = 0;

	protected static Random random = new Random();
	private Node node;
	
	protected String name;
	protected boolean Immortal;
	protected boolean mobility;
	protected Fin fin = new Fin();
	protected Binocular binocular;
	protected Node[][] grid;
	

	public abstract void swim();
	public abstract void eatLotus(Lotus lotus);
	public abstract void sleep();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static int getNoOfWarriors() {
		return noOfWarriors;
	}

	public Node getNode() {
		return node;
	}

	public boolean isImmortal() {
		return Immortal;
	}

	public void setImmortal(boolean Immortal) {
		this.Immortal = Immortal;
	}

	public void setMobility(boolean mobility) {
		this.mobility = mobility;
	}

	public void setNode(Node node) {
		this.node = node;	
	}
	
	public void run() {
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.swim();
	}
}