package final_WBT;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

/**
 * This is the main class having all objects(Composition). Game is started in
 * this class
 * 
 */
public class GameWarriorBringTreasure {
	public static ArrayList<Lotus> lotusList = new ArrayList<>();
	public static ArrayList<Fish> fishList = new ArrayList<>();
	public static ArrayList<Treasure> treasureList = new ArrayList<>();
	public static ArrayList<Warrior> warriorList = new ArrayList<>();

	public static ArrayList<Inhabitant> inhabitantList = new ArrayList<>();

	public static Thread[] warriorThreads;
	public static Thread[] fishThreads;

	protected static boolean treasureGrabbed = false;

	public static void main(String[] args) {
		// A Grid class manages objects locations.

		/*
		 * There are four warriors in our game starting from borders. Able to move
		 * through borders and only one grid move accepted. No two warriors can occupy
		 * the same line crossing. All these availability checking is only up to next
		 * node on grids where he is.
		 */
		Warrior normalWarrior1 = new NormalWarrior("WarriorA", 1, Grid.getGrid());
		Warrior normalWarrior2 = new NormalWarrior("WarriorB", 4,Grid.getGrid());
		Warrior superWarrior1 = new SuperWarrior("SuperWarriorA", 7, Grid.getGrid());
		Warrior superWarrior2 = new SuperWarrior("SuperWarriorB", 10, Grid.getGrid());
		inhabitantList.add(normalWarrior1);
		inhabitantList.add(normalWarrior2);
		inhabitantList.add(superWarrior1);
		inhabitantList.add(superWarrior2);
		warriorList.add(normalWarrior1);
		warriorList.add(normalWarrior2);
		warriorList.add(superWarrior1);
		warriorList.add(superWarrior2);

		/*
		 * Location of fishes is always fixed from the beginning and there are six
		 * fishes.
		 */
		/*Fish rubberFish1 = new RubberFish("RubberFishA");
		Fish rubberFish2 = new RubberFish("RubberFishB");
		Fish killerFish1 = new KillerFish("KillerFishA");
		Fish killerFish2 = new KillerFish("KillerFishB");
		Fish innocentFish1 = new InnocentFish("InnocentFishA");
		Fish innocentFish2 = new InnocentFish("InnocentFishB");
		inhabitantList.add(rubberFish1);
		inhabitantList.add(rubberFish2);
		inhabitantList.add(killerFish1);
		inhabitantList.add(killerFish2);
		inhabitantList.add(innocentFish1);
		inhabitantList.add(innocentFish2);*/

		/*
		 * Five randomly fixed lotus in this game and are fixed.
		 */
		Lotus lotus1 = new Lotus("lotusA");
		Lotus lotus2 = new Lotus("lotusB");
		Lotus lotus3 = new Lotus("lotusC");
		Lotus lotus4 = new Lotus("lotusD");
		Lotus lotus5 = new Lotus("lotusE");
		
		/*
		 * Treasure is fixed and the only at 5,5 in this game and warriors know it.
		 */
		Treasure treasure1 = new Treasure("TheTreasure", 4, 4);
		Visual.PrintWarriorMap();
		System.out.println("\":\", \"#\" and \"+\" indicate innocent fish, rubber fish and monster fish respectively\n"
				+ "\"&\" and \"$\" indicate normal and super warrior accordingly\n"
				+ "\"@\" is the treasure in the middle\n" + "\"*\" indicates lotuses\n");

		for (Inhabitant i : inhabitantList) {
			System.out.println(i.getClass().getName() + " : " + i.getName());
		}
		System.out.println();

		warriorThreads = new Thread[warriorList.size()];
		int count = 0;
		for (Warrior warrior : warriorList) {
			warriorThreads[count] = new Thread(warrior);
			warriorThreads[count].start();
			count++;
		}

		fishThreads = new Thread[fishList.size()];
		count = 0;
		for (Fish fish : fishList) {
			fishThreads[count] = new Thread(fish);
			fishThreads[count].start();
			count++;
		}

	}

	/**
	 * this method is to stop the game can be called implicitly by another method.
	 * or we can call it ourselves if necessary.
	 */
	public static void stopGame() {
		treasureGrabbed = true;
		for (Thread thread : warriorThreads) {
			thread.interrupt();
		}
	}

	/**
	 * this methods is to check whether there is any warrior active means able to
	 * grab the treasure. every warrior is checked by using for loop each time when
	 * it is going to move.
	 */
	public static void stopIfAllWarriorWentOff() {
		for (Warrior warrior : GameWarriorBringTreasure.warriorList) {
			if (warrior.isImmortal()) {
				return;
			} else if (warrior != null) {
				return;
			} else if (warrior.mobility) {
				return;
			}
		}
		stopGame();
		System.out.println("All warriors went off and the Treasure becomes immortal.");
	}
}
