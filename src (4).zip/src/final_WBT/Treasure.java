package final_WBT;
public class Treasure implements Inhabitant{
    private String name;
    private Node node;
    private Warrior[] warriorList;
    
    public Treasure(String name, Warrior...warrior) {
        this.name = name;
        this.warriorList = warrior;
        
        GameWarriorBringTreasure.treasureList.add(this);
    }

    public Node getLocation() {
    	return node;
    }
    
    /**
     * to notify all warrior that warrior is grabbed as on project description
     * @param grabbedWarrior
     */
    public synchronized void notifyTreasureIsGrabbed(Warrior grabbedWarrior) {
    	Fish.setGameStopped(true);
    	for(Warrior warrior: warriorList) {
    		warrior.setTreasureGrabbed(true);
    	}
    	GameWarriorBringTreasure.stopGame();
    	Visual.printOut(String.format(grabbedWarrior.getName()+" has grabbed the treasure and become winner\n"));
    }
    
    public String getName() {
    	return name;
    }

	public Node getNode() {
		return node;
	}
	
	public void setNode(Node node) {
		this.node = node;
	}

}
