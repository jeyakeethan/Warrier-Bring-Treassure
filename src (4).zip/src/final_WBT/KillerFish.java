package final_WBT;

public class KillerFish extends Fish {

	public KillerFish(String name) {
		this.setName(name);
		GameWarriorBringTreasure.fishList.add(this);
	}

	/**
	 * to be called by grid class if coordinates are same. to attack the warrior to
	 * kill warrior if the warrior is not immortal
	 */
	public void attackWarrior(Node node) {
		Warrior warrior = node.getWarrior();
		if (!warrior.isImmortal()) {
			warrior.setMobility(false);
			node.setWarrior(null);
			Visual.printOut(String.format(this.getName() + " has killed " + warrior.getName()+"\n"));
		} else {
			node.setWarrior(null);
			Visual.printOut(String.format("%s has escaped from %s as %s is an immortal\n", warrior.getName(), this.getName(),
					warrior.getName()+"\n"));
		}
	}
}