package final_WBT;

public class InnocentFish extends Fish {
	public InnocentFish(String name) {
		this.setName(name);
		GameWarriorBringTreasure.fishList.add(this);
	}

	/**
	 * to be called by grid class if coordinates are same. to attack the warrior
	 */
	public synchronized void attackWarrior(Node node) {
		Warrior warrior = node.getWarrior();
		Visual.printOut(String.format("I don't make you anything. Calm Down!"));
		node.setWarrior(null);
	}
}
