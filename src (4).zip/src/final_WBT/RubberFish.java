package final_WBT;

public class RubberFish extends Fish {
	public RubberFish(String name) {
		this.setName(name);
		GameWarriorBringTreasure.fishList.add(this);
	}

	/**
	 * to be called by grid class if coordinates are same. to attack the warrior
	 */
	public void attackWarrior(Node node) {
		Warrior warrior = node.getWarrior();
		if (warrior.mobility) {
			if (!warrior.isImmortal()) {
				warrior.setMobility(false);
				Visual.printOut(String.format("%s has eaten fins of the %s => %s can't move anymore\n", this.getName(),
						node.getWarrior().getName(), node.getWarrior().getName()));
			} else {
				Visual.printOut(String.format("%s has escaped from %s as %s is immortal\n", node.getWarrior().getName(),
						this.getName(), node.getWarrior().getName()));
				node.setWarrior(null);
			}
		}
	}
}
